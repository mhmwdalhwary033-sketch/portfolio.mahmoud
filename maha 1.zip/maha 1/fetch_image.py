import urllib.request
import re
import sys

url = 'https://www.linkedin.com/in/maha-abdul-khaleq-94108a279'
req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
try:
    html = urllib.request.urlopen(req).read().decode('utf-8')
    match = re.search(r'property="og:image"\s+content="([^"]+)"', html)
    if match:
        print(match.group(1))
    else:
        print("No image found")
except Exception as e:
    print(str(e))
